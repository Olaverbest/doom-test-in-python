to run this app you have to go to command promt(cmd)
and type "pip install pygame"