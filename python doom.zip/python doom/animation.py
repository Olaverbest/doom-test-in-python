import pygame, sys

class Shotgun(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.sprites = []
        self.is_animating = False

        self.sprites.append(pygame.image.load('assets/shotgun/base/0.png'))

        self.sprites.append(pygame.image.load('assets/shotgun/shot/0.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/1.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/2.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/3.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/4.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/5.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/6.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/7.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/8.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/9.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/10.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/11.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/12.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/13.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/14.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/15.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/16.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/17.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/18.png'))
        self.sprites.append(pygame.image.load('assets/shotgun/shot/19.png'))

        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        
        print(self.is_animating)

        self.rect.topleft = [pos_x, pos_y]
    
    def animate(self):
        self.is_animating = True

    def update(self):
        if self.is_animating == True:
            self.current_sprite += 0.3
            if self.current_sprite >= len(self.sprites):
                self.current_sprite = 0
                self.is_animation = False
            
            self.image = self.sprites[int(self.current_sprite)]

pygame.init()
clock = pygame.time.Clock()

# Creating the sprites and groups
moving_sprites = pygame.sprite.Group()
shotgun = Shotgun(660,200)
moving_sprites.add(shotgun)