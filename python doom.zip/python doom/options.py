developer_mode = True
map_show_grid = False

show_rays = True
show_direction = True

show_fov_bounds = True
show_sight_indicator = True