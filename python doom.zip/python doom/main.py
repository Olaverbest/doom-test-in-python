# packages
from turtle import right
import pygame, sys, math
from pygame.locals import *

# files
from map import *
from options import *
from animation import *

pygame.init()

# global constants
SCREEN_HEIGHT = 480
SCREEN_WIDTH = SCREEN_HEIGHT * 2

HALF_HEIGHT = SCREEN_HEIGHT / 2
HALF_WIDTH = SCREEN_WIDTH / 2

TILE_SIZE = int((SCREEN_WIDTH / 2) / MAP_SIZE)
MAX_DEPTH = int(MAP_SIZE * TILE_SIZE)
FOV = math.pi / 3
HALF_FOV = FOV / 2
CASTED_RAYS = 120 # max amount is 480 but that is BAD
STEP_ANGLE = FOV / CASTED_RAYS
SCALE = (SCREEN_WIDTH / 2) / CASTED_RAYS

# global variables
player_x = (SCREEN_WIDTH / 2) / 2
player_y = (SCREEN_WIDTH / 2) / 2

sensitivity = 0.01

line_multiplier = 50
fov_outline = (0, 255, 0)
sky_color = (200, 20, 0)
floor_color = (50, 50, 50)

max_fps = 30
player_speed = 3
player_angle = math.pi

# map
def draw_map():

    # draw map
    for row in range(MAP_SIZE): # change to "8" if it doesn't work!

        for col in range(MAP_SIZE): # change to "8" if it doesn't work!
            square = row * MAP_SIZE + col

            if map_show_grid:
                pygame.draw.rect (
                win,
                (200, 200, 200) if MAP[square] == '#' else (100, 100, 100),
                (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE - 2, TILE_SIZE - 2)
                )
            else:
                pygame.draw.rect (
                win,
                (200, 200, 200) if MAP[square] == '#' else (100, 100, 100),
                (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                )

    # draw player
    pygame.draw.circle(win, (255, 0, 0), (int(player_x), int(player_y)), 8)

    # drawing direction player faces
    if show_direction:
        pygame.draw.line(win, (0, 255, 0), (player_x, player_y),
        (player_x - math.sin(player_angle) * line_multiplier, player_y + math.cos(player_angle) * line_multiplier), 3)
    else:
        pass

def draw_fov():

    # draw player field of view
    if show_fov_bounds:
        pygame.draw.line(win, (fov_outline), (player_x, player_y),
        (player_x - math.sin(player_angle - HALF_FOV) * line_multiplier, player_y + math.cos(player_angle - HALF_FOV) * line_multiplier), 3)

        pygame.draw.line(win, (fov_outline), (player_x, player_y),
        (player_x - math.sin(player_angle + HALF_FOV) * line_multiplier, player_y + math.cos(player_angle + HALF_FOV) * line_multiplier), 3)
    else:
        pass

# window
win = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("DOOM IN PYTHON BY OLAV")

clock = pygame.time.Clock()

# raycasting algorithm
def cast_rays():
    # define left most angle of fov
    start_angle = player_angle - HALF_FOV

    # loop over casted rays
    for ray in range(CASTED_RAYS):

        # cast ray step by step
        for depth in range(MAX_DEPTH):

            #  gets ray cordinates
            target_x = player_x - math.sin(start_angle) * depth
            target_y = player_y + math.cos(start_angle) * depth

            # converts target x and y cordinates to map col and row
            col = int(target_x / TILE_SIZE)
            row = int(target_y / TILE_SIZE)

            # calculate map square index
            square = row * MAP_SIZE + col

            # ray hits
            if MAP[square] == '#':
                if developer_mode:
                    if show_sight_indicator:
                        if map_show_grid:
                            pygame.draw.rect(win, (0, 255, 0), (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE -2, TILE_SIZE - 2))
                        else:
                            pygame.draw.rect(win, (0, 255, 0), (col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                    else:
                        pass
                else:
                    pass

                # drawing ray
                if developer_mode:
                    if show_rays:
                        pygame.draw.line(win, (255, 255, 0), (player_x, player_y), (target_x, target_y))
                else:
                    pass

                # wall shading
                wall_color = 255 / (1 + depth * depth * 0.0001)

                # fix gopro effect
                depth *= math.cos(player_angle - start_angle)

                # calculate wall height
                wall_height = 21000 / (depth + 0.0001)

                # fix stuck at wall
                if wall_height > SCREEN_HEIGHT: wall_height = SCREEN_HEIGHT

                # draw 3D projection (rectangle by rectangle)
                pygame.draw.rect(win, (wall_color, wall_color, wall_color), (SCREEN_HEIGHT + ray * SCALE,
                (SCREEN_HEIGHT / 2) - wall_height / 2,
                SCALE, wall_height))

                break

        # increment angle by a step
        start_angle += STEP_ANGLE

# moving direction
foreward = True

# game loop
playing = True
while playing:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit(0)
    
    # get user input
    keys = pygame.key.get_pressed()

    if keys[pygame.K_ESCAPE]:
        pygame.quit()
        sys.exit(0)

    # converts target x and y cordinates to map col and row
    col = int(player_x / TILE_SIZE)
    row = int(player_y / TILE_SIZE)

    # calculate map square index
    square = row * MAP_SIZE + col

    # player hits the wall (collition detection)
    if MAP[square] == '#':
        if foreward:
            player_x -= -math.sin(player_angle) * player_speed
            player_y -= math.cos(player_angle) * player_speed
        else:
            player_x += -math.sin(player_angle) * player_speed
            player_y += math.cos(player_angle) * player_speed

    # update 2D background
    pygame.draw.rect(win, (0, 0, 0), (0, 0, SCREEN_HEIGHT, SCREEN_HEIGHT))

    # update 3D background
    pygame.draw.rect(win, floor_color, (480, SCREEN_HEIGHT / 2, SCREEN_HEIGHT, SCREEN_HEIGHT))
    pygame.draw.rect(win, sky_color, (480, -SCREEN_HEIGHT / 2, SCREEN_HEIGHT, SCREEN_HEIGHT))

    # draw 2D map and fov
    if developer_mode:
        draw_map()
        draw_fov()
    else:
        pass

    # apply raycasting
    cast_rays()

    # gets mouse position
    mx, my = pygame.mouse.get_pos()

    # handles rotation
    if pygame.mouse.get_focused():
            difference = pygame.mouse.get_pos()[0] - HALF_WIDTH
            pygame.mouse.set_pos([HALF_WIDTH, HALF_HEIGHT])
            player_angle += difference * sensitivity
    
    if pygame.mouse.get_pressed():
        shotgun.animate()

    # handle user input
    if keys[pygame.K_LEFT]: player_angle -= 0.1
    if keys[pygame.K_RIGHT]: player_angle += 0.1
    
    if keys[pygame.K_w]:
        foreward = True
        player_x += -math.sin(player_angle) * player_speed
        player_y += math.cos(player_angle) * player_speed
    if keys[pygame.K_s]:
        foreward = False
        player_x -= -math.sin(player_angle) * player_speed
        player_y -= math.cos(player_angle) * player_speed
    if keys[pygame.K_a]:
        player_x += math.cos(player_angle) * player_speed
        player_y += math.sin(player_angle) * player_speed
    if keys[pygame.K_d]:
        player_x -= math.cos(player_angle) * player_speed
        player_y -= math.sin(player_angle) * player_speed

    # frames per second
    clock.tick(max_fps)

    # display FPS
    fps = str(int(clock.get_fps()))
    
    # pick up the font
    font = pygame.font.SysFont('Monospace Regular', 30)
    
    # create font surface
    fps_surface = font.render("FPS: " + fps, False, (255, 255, 255))
    
    # print FPS to screen
    if developer_mode:
        win.blit(fps_surface, (480, 0))
    else:
        win.blit(fps_surface, (0, 0))

    # updates screen
    #moving_sprites.draw(win)
    #moving_sprites.update()
    pygame.display.flip()
